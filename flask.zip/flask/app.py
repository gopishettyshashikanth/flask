#alias python=python3
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy 
from flask_marshmallow import Marshmallow 
import os

# Init app
app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))
# Database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'db.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# Init db
db = SQLAlchemy(app)
# Init ma
ma = Marshmallow(app)

# Product Class/Model
class Product(db.Model):

  id = db.Column(db.Integer, primary_key=True)
  name = db.Column(db.String(100), unique=True)
  description = db.Column(db.String(200))
  price = db.Column(db.Float)
  qty = db.Column(db.Integer)

  def __init__(self, name, description, price, qty):
    self.name = name
    self.description = description
    self.price = price
    self.qty = qty

# Product Schema
class ProductSchema(ma.Schema):
  class Meta:
    fields = ('id', 'name', 'description', 'price', 'qty')

# Init schema
product_schema = ProductSchema()
products_schema = ProductSchema(many=True)

# Create a Product
@app.route('/product', methods=['POST'])
def add_product():
  name = request.json['name']
  description = request.json['description']
  price = request.json['price']
  qty = request.json['qty']

  new_product = Product(name, description, price, qty)

  db.session.add(new_product)
  db.session.commit()
  
  return product_schema.jsonify(new_product)

# Get All Products
@app.route('/product', methods=['GET'])
def get_products():
  all_products = Product.query.all()
  
  result = products_schema.dump(all_products)
  return jsonify(result)

# Get Single Products
@app.route('/product/<id>', methods=['GET'])
def get_product(id):
  product = Product.query.get(id)
  return product_schema.jsonify(product)

# Update a Product
@app.route('/product/<id>', methods=['PUT'])
def update_product(id):
  product = Product.query.get(id)

  name = request.json['name']
  description = request.json['description']
  price = request.json['price']
  qty = request.json['qty']

  product.name = name
  product.description = description
  product.price = price
  product.qty = qty

  db.session.commit()

  return product_schema.jsonify(product)

# Delete Product
@app.route('/product/<id>', methods=['DELETE'])
def delete_product(id):
  product = Product.query.get(id)
  db.session.delete(product)
  db.session.commit()

  return product_schema.jsonify(product)


class UserModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True)
    password = db.Column(db.String(120))
    weekday = db.relationship('weekDay', cascade='all,delete-orphan', single_parent=True, backref=db.backref('usermodel', lazy='joined'))

    def __init__(self, username, password):
      self.username = username
      self.password = password
    

class weekDay(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    #Defining the Foreign Key on the Child Table
    dayname = db.Column(db.String(15))
    usermodel_id = db.Column(db.Integer, db.ForeignKey('user_model.id'))  

    def __init__(self,dayname, usermodel_id):
      self.dayname = dayname
      self.usermodel_id = usermodel_id


class UserSchema(ma.Schema):
    class Meta:
      fields = ('id', 'username','password',)

class WeekdaySchema(ma.Schema):
  class Meta:
    fields = ('id', 'dayname')

user_schema = UserSchema()
users_schema = UserSchema(many=True)

weekday_schema = WeekdaySchema()
weekday_schema = WeekdaySchema(many=True)

@app.route('/user', methods=['POST'])
def add_user():
  username = request.json['username']
  password = request.json['password']
  
  new_user = UserModel(username,password)
  db.session.add(new_user)
  db.session.commit()

  return "yes"
  #return users_schema.jsonify(new_user)

@app.route('/weekday', methods=['POST'])
def add_weekday():
  dayname = request.json['dayname']
  username = request.json['username']
    
  u = UserModel.query.filter_by(username=username).first()
  new_user = weekDay(dayname,u.id)
  db.session.add(new_user)
  db.session.commit()

  return "yes"
  #return users_schema.jsonify(new_user)

@app.route('/weekday/<id>', methods=['GET'])
def get_weekday(id):
  weekday = weekDay.query.get(id)
  username = UserModel.query.get(weekday.usermodel_id).username
  
  d = {
    'weekday' : weekday.dayname,
    'username':username
  }
  
  return jsonify(d)    

# Run Server
if __name__ == '__main__':
  app.run(debug=True)
